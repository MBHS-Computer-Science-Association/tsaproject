module.exports = {
  token : 'AN-OAUTH2-TOKEN',
  name  : 'Your Name',
  email : 'user@email.com'
};